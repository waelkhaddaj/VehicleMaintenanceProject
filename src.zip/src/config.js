export const API_URL = "https://vehicle-maint-backend-wael-ecfbf1082303.herokuapp.com";
